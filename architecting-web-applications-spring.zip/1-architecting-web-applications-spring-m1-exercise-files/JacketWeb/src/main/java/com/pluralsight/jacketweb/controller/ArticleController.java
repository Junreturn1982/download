package com.pluralsight.jacketweb.controller;

import javax.inject.Inject;

import org.apache.commons.logging.Log;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = { "/", "/article" })
public class ArticleController {

	private Log log;

	@Inject
	public ArticleController(Log log) {
		this.log = log;
	}

	@RequestMapping(value = { "/", "" })
	public ModelAndView index() {
		ModelAndView mv = new ModelAndView("article/index");
		mv.addObject("articles");
		
		return mv;
	}
	
}
