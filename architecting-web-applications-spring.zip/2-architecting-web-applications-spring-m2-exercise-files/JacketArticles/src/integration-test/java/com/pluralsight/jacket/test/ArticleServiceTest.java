package com.pluralsight.jacket.test;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pluralsight.jacket.article.repository.ArticleRepository;
import com.pluralsight.jacket.article.service.JacketArticleService;
import com.pluralsight.jacket.article.service.models.GetJacketArticle;
import com.pluralsight.repository.AbstractTest;

public class ArticleServiceTest extends AbstractTest {

	@Autowired
	ArticleRepository repository;
	@Autowired
	JacketArticleService service;

	@Test
	public void getAllEntries_should_get_all_articles_from_datastore() {

		List<GetJacketArticle> Article = service.getAllArticles();

		assertThat(Article.size()).isEqualTo(2);
	}
}
