package com.pluralsight.jacket.test;


import com.pluralsight.repository.ApplicationConfiguration;


public class ArticlesConfiguration extends ApplicationConfiguration {

}
