package com.pluralsight.jacket.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import org.apache.commons.logging.Log;
import org.junit.Before;
import org.junit.Test;

import com.pluralsight.jacket.article.repository.ArticleRepository;
import com.pluralsight.jacket.article.service.ArticleDetailsServiceOnArticleRepository;
import com.pluralsight.jacket.article.service.models.GetJacketArticle;
import com.pluralsight.jacket.data.models.Article;

public class JacketEntryServiceOnRepositoryTest {
	ArticleDetailsServiceOnArticleRepository jacketArticleServiceOnRepository;
	ArticleRepository articleRepository;
	Log log;
	ArticleDetailsServiceOnArticleRepository service;

	@Before
	public void before() {
		articleRepository = mock(ArticleRepository.class);
		log = mock(Log.class);
		service = new ArticleDetailsServiceOnArticleRepository(articleRepository, log);
	}

	@Test
	public void getAllEntries_should_return_all_articles() throws SerialException, SQLException {

		Article entry = new Article();		

		when(articleRepository.findAll()).thenReturn(Arrays.asList(entry));

		List<GetJacketArticle> articles = service.getAllArticles();

		assertThat(articles.size()).isEqualTo(1);
	}

}
