package com.pluralsight.jacketweb.controller;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.logging.Log;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.pluralsight.jacket.data.models.Article;
import com.pluralsight.jacket.data.repository.ArticleRepository;
import com.pluralsight.jacketweb.viewmodels.Entry;

@Controller
@RequestMapping(value = { "/", "/article" })
public class ArticleController {

	private Log log;
	private ArticleRepository repository;

	@Inject
	public ArticleController(ArticleRepository repository, Log log) {
		this.repository = repository;
		this.log = log;
	}

	@RequestMapping(value = { "/", "" })
	public ModelAndView index() {
		Iterable<Article> serviceEntries = repository.findAll();
		List<Entry> articles = new ArrayList<Entry>();
		serviceEntries.forEach(e -> {
			Entry entry = new Entry();
			entry.setTitle(e.getTitle());
			articles.add(entry);
		});

		ModelAndView mv = new ModelAndView("article/index");
		mv.addObject("articles", articles);
		
		return mv;
	}
	
}
